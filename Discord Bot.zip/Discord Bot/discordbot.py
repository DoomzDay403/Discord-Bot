import subprocess 
import sys 
import os 
def create_requirements_file(): 
    requirements_content = """ 
    discord.py 
    nest_asyncio
    """ 
    with open('requirements.txt', 'w') as f: 
        f.write(requirements_content.strip()) 

def install_requirements(): 
    if os.path.exists('requirements.txt'): 
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"]) 
    else: 
        print("requirements.txt not found. Make sure it exists in the same directory as the script.") 

# Create the requirements.txt file 
create_requirements_file() 

# Install the required packages 
install_requirements()

import discord
from discord.app_commands.checks import has_permissions
from discord.ext import commands
import json
import os
from datetime import datetime
import sys
import threading
import tkinter as tk
from queue import Queue
import asyncio
import nest_asyncio

CONFIG_FILE = 'config.json'
message_logging = False
command_logging = False
log_queue = Queue()
nest_asyncio.apply()

def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return None

def save_config(token):
    with open(CONFIG_FILE, 'w') as f:
        json.dump({'token': token}, f)

def setup_bot():
    intents = discord.Intents.default()
    intents.message_content = True
    intents.members = True
    return commands.Bot(command_prefix='!', intents=intents)

class LogWindow(tk.Toplevel):
    def __init__(self, master):
        super().__init__(master)
        self.title("Discord Bot Logs")
        self.geometry("600x400")
        
        self.text_area = tk.Text(self, wrap=tk.WORD)
        self.text_area.pack(expand=True, fill='both')
        
        self.after(100, self.check_queue)

    def check_queue(self):
        try:
            while not log_queue.empty():
                log = log_queue.get_nowait()
                self.text_area.insert(tk.END, log + '\n')
                self.text_area.see(tk.END)
        except:
            pass
        self.after(100, self.check_queue)

class MainApplication(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Discord Bot Control Panel")
        self.geometry("300x400")
        
        # Create log window
        self.log_window = LogWindow(self)
        
        tk.Label(self, text="=== Bot Control Panel ===", font=('Arial', 14)).pack(pady=10)
        
        # Message Logging Toggle
        self.msg_var = tk.BooleanVar()
        tk.Checkbutton(self, text="Message Logging", variable=self.msg_var, 
                      command=self.toggle_message_logging).pack(pady=5)
        
        # Command Logging Toggle
        self.cmd_var = tk.BooleanVar()
        tk.Checkbutton(self, text="Command Logging", variable=self.cmd_var,
                      command=self.toggle_command_logging).pack(pady=5)
        
        # Stats Button
        tk.Button(self, text="View Bot Stats", command=self.show_stats).pack(pady=5)
        
        # Exit Button
        tk.Button(self, text="Exit Bot", command=self.exit_bot).pack(pady=5)
        
        # Stats Label
        self.stats_label = tk.Label(self, text="", justify=tk.LEFT)
        self.stats_label.pack(pady=10)

    def toggle_message_logging(self):
        global message_logging
        message_logging = self.msg_var.get()
        log_queue.put(f"Message logging {'enabled' if message_logging else 'disabled'}")

    def toggle_command_logging(self):
        global command_logging
        command_logging = self.cmd_var.get()
        log_queue.put(f"Command logging {'enabled' if command_logging else 'disabled'}")

    def show_stats(self):
        stats = f"\nBot Stats:\n"
        stats += f"Servers: {len(client.guilds)}\n"
        stats += f"Users: {sum(guild.member_count for guild in client.guilds)}\n"
        stats += f"Ping: {round(client.latency * 1000)}ms"
        self.stats_label.config(text=stats)

    def exit_bot(self):
        asyncio.create_task(client.close())
        self.quit()
        sys.exit()

client = setup_bot()

# Replace this with the name of the role you want to allow
ROLE_NAME = "DD403"

def has_role(ctx):
    role = discord.utils.find(lambda r: r.name == ROLE_NAME, ctx.author.roles)
    return role is not None

@client.event
async def on_ready():
    print(f'{client.user} is ready!')
    log_queue.put(f"Bot logged in as {client.user}")

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message_logging:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_queue.put(f"[MESSAGE] [{timestamp}] {message.author} in #{message.channel}: {message.content}")

    await client.process_commands(message)

@client.before_invoke
async def before_command(ctx):
    if command_logging:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_queue.put(f"[COMMAND] [{timestamp}] {ctx.author} used: {ctx.message.content}")

@client.command()
@commands.check(has_role)
async def ban(ctx, member: discord.Member, *, reason=None):
    if ctx.author.guild_permissions.ban_members:
        try:
            await member.ban(reason=reason)
            await ctx.send(f'{member.name} has been banned.\nReason: {reason}')
        except discord.Forbidden:
            await ctx.send("I don't have permission to ban members!")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")
    else:
        await ctx.send("You don't have permission to ban members!")

@client.command()
@commands.check(has_role)
async def fakemsg(ctx, member: discord.Member, *, message):
    await ctx.message.delete()
    webhook = await ctx.channel.create_webhook(name=member.name)
    try:
        await webhook.send(message, username=member.name, avatar_url=member.avatar.url)
        await webhook.delete()
    except Exception as e:
        await ctx.send(f"Error: {e}")
        await webhook.delete()

@client.command(help="Ghost ping a user and delete the message")
@commands.check(has_role)
async def ghostping(ctx, member: discord.Member):
    await ctx.message.delete()
    msg = await ctx.send(member.mention)
    await msg.delete()

@client.command(help="Clear a specified number of messages")
@has_permissions(manage_messages=True)
@commands.check(has_role)
async def clear(ctx, amount: int):
    deleted = await ctx.channel.purge(limit=amount + 1)
    msg = await ctx.send(f'Deleted {len(deleted)-1} messages.')
    await asyncio.sleep(3)
    await msg.delete()
    
@client.command(help="Get information about the server")
@commands.check(has_role)
async def serverinfo(ctx):
    guild = ctx.guild
    embed = discord.Embed(title=f"{guild.name} Information", color=discord.Color.blue())
    embed.add_field(name="Owner", value=guild.owner)
    embed.add_field(name="Created On", value=guild.created_at.strftime("%b %d, %Y"))
    embed.add_field(name="Member Count", value=guild.member_count)
    embed.add_field(name="Channel Count", value=len(guild.channels))
    embed.add_field(name="Role Count", value=len(guild.roles))
    embed.set_thumbnail(url=guild.icon.url if guild.icon else None)
    await ctx.send(embed=embed)

@client.command(help="Get information about a user")
@commands.check(has_role)
async def userinfo(ctx, member: discord.Member = None):
    member = member or ctx.author
    embed = discord.Embed(title=f"{member.name}'s Information", color=member.color)
    embed.add_field(name="Joined Server", value=member.joined_at.strftime("%b %d, %Y"))
    embed.add_field(name="Account Created", value=member.created_at.strftime("%b %d, %Y"))
    embed.add_field(name="Top Role", value=member.top_role)
    embed.set_thumbnail(url=member.avatar.url)
    await ctx.send(embed=embed)

@client.command(help="Lock the channel")
@has_permissions(manage_channels=True)
@commands.check(has_role)
async def lock(ctx):
    await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=False)
    await ctx.send('Channel locked. 🔒')

@client.command(help="Unlock the channel")
@has_permissions(manage_channels=True)
@commands.check(has_role)
async def unlock(ctx):
    await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=True)
    await ctx.send('Channel unlocked. 🔓')

@client.command(help="Make the bot say something")
@commands.check(has_role)
async def say(ctx, *, message):
    await ctx.message.delete()
    await ctx.send(message)

@client.command(help="Mock text")
@commands.check(has_role)
async def mock(ctx, *, text):
    await ctx.send(''.join(c.upper() if i % 2 else c.lower() for i, c in enumerate(text)))

@client.command(help="Reverse text")
@commands.check(has_role)
async def reverse(ctx, *, text):
    await ctx.send(text[::-1])

@client.command() 
@commands.check(has_role) 
async def stop(ctx): 
    await ctx.send("Shutting down...") 
    await client.change_presence(status=discord.Status.offline) 
    await client.close() 
    sys.exit(0)

@client.command()
@commands.check(has_role)
async def list(ctx):
    await ctx.send("!ban\n!fakemsg\n!ghostping\n!clear\n!channel_clear\n!serverinfo\n!userinfo\n!lock\n!unlock\n!say\n!mock\n!reverse\n!stop\n!list\n!ranks\n!remove_role\n!give_role\n!vcmute\n!vcunmute\n!timeout\n!untimeout\n!announcement\n!bot_link\n!server_link\n!leave\n!view_invites\n!delete_invite\n!TCH\n!whitelist\n!delete_channel")

@client.command(help="List all ranks on the server from top to bottom")
@commands.check(has_role)
async def ranks(ctx):
    roles = sorted(ctx.guild.roles, key=lambda role: role.position, reverse=True)
    role_names = [role.name for role in roles]
    roles_str = "\n".join(role_names)
    await ctx.send(f"Ranks on this serveer from top to bottom:\n```{roles_str}```")

@client.command(help="Remove a role from a user")
@commands.check(has_role)
async def remove_role(ctx, member: discord.Member, role: discord.Role):
    try:
        await member.remove_roles(role)
        await ctx.send(f"Role {role.name} has been removed from {member.mention}.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

@client.command(help="Give a role to a user")
@commands.check(has_role)
async def give_role(ctx, member: discord.Member, role: discord.Role):
    try:
        await member.add_roles(role)
        await ctx.send(f"Role {role.name} has been given to {member.mention}.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

@client.command(help="Mute a user in voice channels")
@commands.check(has_role)
async def vcmute(ctx, member: discord.Member):
    try:
        await member.edit(mute=True)
        await ctx.send(f"{member.mention} has been muted.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

@client.command(help="Unmute a user in voice channels")
@commands.check(has_role)
async def vcunmute(ctx, member: discord.Member):
    try:
        await member.edit(mute=False)
        await ctx.send(f"{member.mention} has been unmuted.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

from datetime import timedelta

from datetime import timedelta

@client.command(help="Timeout a user for a specified duration (e.g., 4s, 4m, 4h, 4d, 4y)")
@commands.check(has_role)
@has_permissions(mute_members=True)
async def timeout(ctx, member: discord.Member, duration: str):
    try:
        time_dict = {'s': 'seconds', 'm': 'minutes', 'h': 'hours', 'd': 'days', 'y': 'years'}
        
        unit = duration[-1]
        if unit not in time_dict:
            await ctx.send("Invalid time unit. Use s, m, h, d, y.")
            return

        time_value = int(duration[:-1])
        delta = timedelta(**{time_dict[unit]: time_value})
        end_time = discord.utils.utcnow() + delta
        await member.edit(timed_out_until=end_time)
        
        await ctx.send(f"{member.mention} has been timed out for {duration}.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")


@client.command(help="Remove timeout from a user")
@commands.check(has_role)
@has_permissions(mute_members=True)
async def untimeout(ctx, member: discord.Member):
    try:
        await member.edit(timed_out_until=None)
        await ctx.send(f"{member.mention} has been removed from timeout.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

@client.command(help="Send an announcement to @everyone and delete the command message")
@commands.check(has_role)
async def announcement(ctx, *, announcement_text: str):
    try:
        announcer = ctx.message.author.mention
        announcement_message = f"""
        :loudspeaker: **Announcement** :loudspeaker:
        ---------------------------------------------
        :bell: @everyone

        {announcer} has announced:

        {announcement_text}
        
        ---------------------------------------------
        :pushpin: Please check this out!
        """
        await ctx.send(announcement_message)
        await ctx.message.delete()
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

@client.command(help="Clear all messages in the current channel")
@commands.check(has_role)
@has_permissions(manage_messages=True)
async def channel_clear(ctx):
    try:
        await ctx.send("Clearing all messages...")

        def is_not_pinned(msg):
            return not msg.pinned

        deleted = await ctx.channel.purge(limit=None, check=is_not_pinned)
        await ctx.send(f"Cleared {len(deleted)} messages.")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

@client.command(help="Get the bot's invite link")
@commands.check(has_role)
async def bot_link(ctx):
    bot_id = client.user.id
    invite_link = f"https://discord.com/api/oauth2/authorize?client_id={bot_id}&permissions=8&scope=bot"
    await ctx.send(f"Invite the bot to your server using this link:\n{invite_link}")


@client.command(help="Get an invite link for the current server")
@commands.check(has_role)
@has_permissions(create_instant_invite=True)
async def server_link(ctx):
    try:
        invite = await ctx.channel.create_invite(max_age=0, max_uses=0)
        await ctx.send(f"Invite link for this server:\n{invite.url}")
    except Exception as e:
        await ctx.send(f"An error occurred: {e}")

@client.command(help="Make the bot leave the server")
@commands.check(has_role)
async def leave(ctx):
    await ctx.send("Goodbye! I hope to see you again!")
    await ctx.guild.leave()

@client.command(help="List all active invites with letters assigned, expiration dates, and creators")
@commands.check(has_role)
async def view_invites(ctx):
    invites = await ctx.guild.invites()
    if not invites:
        await ctx.send("There are no active invites.")
        return
    
    invite_list = ""
    letter = 97  # ASCII 'a'
    invite_mapping = {}

    for invite in invites:
        expire_date = invite.expires_at.strftime("%Y-%m-%d %H:%M:%S") if invite.expires_at else "Never"
        invite_list += f"{chr(letter)}. {invite.url} | Expires: {expire_date} | Created by: {invite.inviter}\n"
        invite_mapping[chr(letter)] = invite
        letter += 1

    await ctx.send(f"Active Invites:\n{invite_list}")

    # Store the invite mapping for later use
    with open('invite_mapping.json', 'w') as f:
        json.dump({k: v.url for k, v in invite_mapping.items()}, f)

@client.command(help="Delete a specific invite by letter")
@commands.check(has_role)
async def delete_invite(ctx, letter: str):
    letter = letter.lower()
    
    # Load the invite mapping
    if os.path.exists('invite_mapping.json'):
        with open('invite_mapping.json', 'r') as f:
            invite_mapping = json.load(f)
    else:
        await ctx.send("No invite mapping found. Please use !view_invites first.")
        return
    
    if letter in invite_mapping:
        invite_url = invite_mapping[letter]
        invites = await ctx.guild.invites()
        for invite in invites:
            if invite.url == invite_url:
                await invite.delete()
                await ctx.send(f"Invite {letter}. {invite_url} has been deleted.")
                return
    
    await ctx.send(f"No invite found for letter {letter}. Please use !view_invites first.")

@client.command(help="Create a new private test channel")
@commands.check(has_role)
async def TCH(ctx):
    guild = ctx.guild
    author = ctx.author

    # Create a new private channel
    overwrites = {
        guild.default_role: discord.PermissionOverwrite(read_messages=False),
        author: discord.PermissionOverwrite(read_messages=True),
        guild.me: discord.PermissionOverwrite(read_messages=True)
    }

    try:
        test_channel = await guild.create_text_channel('test-channel', overwrites=overwrites)
        await ctx.send(f"Private test channel created: {test_channel.mention}")
    except Exception as e:
        await ctx.send(f"An error occurred while creating the test channel: {e}")

@client.command(help="Show a list of all users with the specified role, including their username")
@commands.check(has_role)
async def whitelist(ctx):
    role_name = ROLE_NAME  # Use the role name specified in ROLE_NAME
    role = discord.utils.get(ctx.guild.roles, name=role_name)
    
    if not role:
        await ctx.send(f"Role '{role_name}' not found.")
        return

    members_with_role = [member for member in ctx.guild.members if role in member.roles]
    
    if not members_with_role:
        await ctx.send(f"No members found with the role '{role_name}'.")
        return

    embed = discord.Embed(title=f"Members with the role '{role_name}'", color=discord.Color.blue())

    for member in members_with_role:
        embed.add_field(name=member.display_name, value=member.mention, inline=False)

    await ctx.send(embed=embed)

@client.command(help="Delete a specific channel by its ID")
@commands.check(has_role)
async def delete_channel(ctx, channel_id: int):
    channel = client.get_channel(channel_id)
    
    if channel:
        try:
            await channel.delete()
            await ctx.send(f"Channel {channel.name} with ID {channel.id} has been deleted.")
        except Exception as e:
            await ctx.send(f"An error occurred while deleting the channel: {e}")
    else:
        await ctx.send(f"No channel found with ID {channel_id}.")


async def run_bot(token):
    try:
        await client.start(token)
    except discord.LoginFailure:
        print("Failed to login. Token might be invalid.")
        os.remove(CONFIG_FILE)
        print("Token file removed. Please restart the bot and enter a valid token.")
    except Exception as e:
        print(f"An error occurred: {e}")

def main():
    config = load_config()
    
    if config and config.get('token'):
        while True:
            choice = input("Existing token found. Would you like to:\n1. Use existing token\n2. Enter new token\nChoice (1 or 2): ")
            if choice in ['1', '2']:
                break
            print("Please enter 1 or 2")

        if choice == '2':
            token = input("Please enter your new bot token: ")
            save_config(token)
        else:
            token = config['token']
    else:
        token = input("Please enter your bot token: ")
        save_config(token)

    app = MainApplication()
    
    # Run the bot in a separate thread
    bot_thread = threading.Thread(target=lambda: asyncio.run(run_bot(token)), daemon=True)
    bot_thread.start()
    
    # Run the GUI main loop
    app.mainloop()

if __name__ == "__main__":
    main()